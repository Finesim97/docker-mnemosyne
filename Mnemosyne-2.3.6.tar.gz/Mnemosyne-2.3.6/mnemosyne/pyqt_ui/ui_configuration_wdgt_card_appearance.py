# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'configuration_wdgt_card_appearance.ui'
#
# Created: Fri Apr 29 13:29:50 2016
#      by: PyQt4 UI code generator 4.10.3
#
# WARNING! All changes made in this file will be lost!

from mnemosyne.libmnemosyne.translator import _
from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ConfigurationWdgtCardAppearance(object):
    def setupUi(self, ConfigurationWdgtCardAppearance):
        ConfigurationWdgtCardAppearance.setObjectName(_fromUtf8("ConfigurationWdgtCardAppearance"))
        ConfigurationWdgtCardAppearance.resize(374, 256)
        self.verticalLayout_2 = QtGui.QVBoxLayout(ConfigurationWdgtCardAppearance)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label_2 = QtGui.QLabel(ConfigurationWdgtCardAppearance)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout.addWidget(self.label_2)
        self.card_types_widget = QtGui.QComboBox(ConfigurationWdgtCardAppearance)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.MinimumExpanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.card_types_widget.sizePolicy().hasHeightForWidth())
        self.card_types_widget.setSizePolicy(sizePolicy)
        self.card_types_widget.setObjectName(_fromUtf8("card_types_widget"))
        self.horizontalLayout.addWidget(self.card_types_widget)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.line_4 = QtGui.QFrame(ConfigurationWdgtCardAppearance)
        self.line_4.setFrameShape(QtGui.QFrame.HLine)
        self.line_4.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_4.setObjectName(_fromUtf8("line_4"))
        self.verticalLayout.addWidget(self.line_4)
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 0, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem1, 0, 1, 1, 1)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem2, 0, 2, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.line = QtGui.QFrame(ConfigurationWdgtCardAppearance)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.verticalLayout.addWidget(self.line)
        self.horizontal_layout_bg_colour = QtGui.QHBoxLayout()
        self.horizontal_layout_bg_colour.setObjectName(_fromUtf8("horizontal_layout_bg_colour"))
        self.bg_label = QtGui.QLabel(ConfigurationWdgtCardAppearance)
        self.bg_label.setObjectName(_fromUtf8("bg_label"))
        self.horizontal_layout_bg_colour.addWidget(self.bg_label)
        self.background_button = QtGui.QPushButton(ConfigurationWdgtCardAppearance)
        self.background_button.setObjectName(_fromUtf8("background_button"))
        self.horizontal_layout_bg_colour.addWidget(self.background_button)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontal_layout_bg_colour.addItem(spacerItem3)
        self.align_label = QtGui.QLabel(ConfigurationWdgtCardAppearance)
        self.align_label.setObjectName(_fromUtf8("align_label"))
        self.horizontal_layout_bg_colour.addWidget(self.align_label)
        self.alignment = QtGui.QComboBox(ConfigurationWdgtCardAppearance)
        font = QtGui.QFont()
        font.setItalic(False)
        self.alignment.setFont(font)
        self.alignment.setObjectName(_fromUtf8("alignment"))
        self.alignment.addItem(_fromUtf8(""))
        self.alignment.addItem(_fromUtf8(""))
        self.alignment.addItem(_fromUtf8(""))
        self.horizontal_layout_bg_colour.addWidget(self.alignment)
        self.verticalLayout.addLayout(self.horizontal_layout_bg_colour)
        self.line_non_latin = QtGui.QFrame(ConfigurationWdgtCardAppearance)
        self.line_non_latin.setFrameShape(QtGui.QFrame.HLine)
        self.line_non_latin.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_non_latin.setObjectName(_fromUtf8("line_non_latin"))
        self.verticalLayout.addWidget(self.line_non_latin)
        self.non_latin_layout = QtGui.QHBoxLayout()
        self.non_latin_layout.setObjectName(_fromUtf8("non_latin_layout"))
        self.label_non_latin_1 = QtGui.QLabel(ConfigurationWdgtCardAppearance)
        self.label_non_latin_1.setObjectName(_fromUtf8("label_non_latin_1"))
        self.non_latin_layout.addWidget(self.label_non_latin_1)
        self.non_latin_font_size_increase = QtGui.QSpinBox(ConfigurationWdgtCardAppearance)
        self.non_latin_font_size_increase.setObjectName(_fromUtf8("non_latin_font_size_increase"))
        self.non_latin_layout.addWidget(self.non_latin_font_size_increase)
        self.label_non_latin_2 = QtGui.QLabel(ConfigurationWdgtCardAppearance)
        self.label_non_latin_2.setObjectName(_fromUtf8("label_non_latin_2"))
        self.non_latin_layout.addWidget(self.label_non_latin_2)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.non_latin_layout.addItem(spacerItem4)
        self.verticalLayout.addLayout(self.non_latin_layout)
        self.label_non_latin_3 = QtGui.QLabel(ConfigurationWdgtCardAppearance)
        self.label_non_latin_3.setWordWrap(True)
        self.label_non_latin_3.setObjectName(_fromUtf8("label_non_latin_3"))
        self.verticalLayout.addWidget(self.label_non_latin_3)
        spacerItem5 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem5)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        spacerItem6 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem6)
        self.preview_button = QtGui.QPushButton(ConfigurationWdgtCardAppearance)
        self.preview_button.setAutoDefault(False)
        self.preview_button.setObjectName(_fromUtf8("preview_button"))
        self.horizontalLayout_5.addWidget(self.preview_button)
        spacerItem7 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem7)
        self.verticalLayout.addLayout(self.horizontalLayout_5)
        self.verticalLayout_2.addLayout(self.verticalLayout)

        self.retranslateUi(ConfigurationWdgtCardAppearance)
        QtCore.QObject.connect(self.preview_button, QtCore.SIGNAL(_fromUtf8("clicked()")), ConfigurationWdgtCardAppearance.preview)
        QtCore.QObject.connect(self.card_types_widget, QtCore.SIGNAL(_fromUtf8("currentIndexChanged(QString)")), ConfigurationWdgtCardAppearance.card_type_changed)
        QtCore.QObject.connect(self.background_button, QtCore.SIGNAL(_fromUtf8("clicked()")), ConfigurationWdgtCardAppearance.update_background_colour)
        QtCore.QObject.connect(self.alignment, QtCore.SIGNAL(_fromUtf8("activated(int)")), ConfigurationWdgtCardAppearance.update_alignment)
        QtCore.QMetaObject.connectSlotsByName(ConfigurationWdgtCardAppearance)

    def retranslateUi(self, ConfigurationWdgtCardAppearance):
        ConfigurationWdgtCardAppearance.setWindowTitle(_('Form'))
        self.label_2.setText(_('Card type:'))
        self.bg_label.setText(_('Background:'))
        self.background_button.setText(_('Set colour'))
        self.align_label.setText(_('Alignment:'))
        self.alignment.setItemText(0, _('Left'))
        self.alignment.setItemText(1, _('Center'))
        self.alignment.setItemText(2, _('Right'))
        self.label_non_latin_1.setText(_('Increase size of non-latin characters by'))
        self.label_non_latin_2.setText(_('points.'))
        self.label_non_latin_3.setText(_('(This setting will be overridden in card types cloned from \'Vocabulary\'.)'))
        self.preview_button.setText(_('&Preview'))

