# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'configuration_wdgt_main.ui'
#
# Created: Fri Apr 29 13:29:50 2016
#      by: PyQt4 UI code generator 4.10.3
#
# WARNING! All changes made in this file will be lost!

from mnemosyne.libmnemosyne.translator import _
from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ConfigurationWdgtMain(object):
    def setupUi(self, ConfigurationWdgtMain):
        ConfigurationWdgtMain.setObjectName(_fromUtf8("ConfigurationWdgtMain"))
        ConfigurationWdgtMain.resize(457, 375)
        self.verticalLayout_6 = QtGui.QVBoxLayout(ConfigurationWdgtMain)
        self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
        self.verticalLayout_5 = QtGui.QVBoxLayout()
        self.verticalLayout_5.setObjectName(_fromUtf8("verticalLayout_5"))
        self.groupBox = QtGui.QGroupBox(ConfigurationWdgtMain)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout_2.addWidget(self.label_2)
        self.new_cards = QtGui.QComboBox(self.groupBox)
        self.new_cards.setObjectName(_fromUtf8("new_cards"))
        self.new_cards.addItem(_fromUtf8(""))
        self.new_cards.addItem(_fromUtf8(""))
        self.horizontalLayout_2.addWidget(self.new_cards)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.horizontalLayout_3.addWidget(self.label_3)
        self.scheduled_cards = QtGui.QComboBox(self.groupBox)
        self.scheduled_cards.setObjectName(_fromUtf8("scheduled_cards"))
        self.scheduled_cards.addItem(_fromUtf8(""))
        self.scheduled_cards.addItem(_fromUtf8(""))
        self.horizontalLayout_3.addWidget(self.scheduled_cards)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout.addWidget(self.label)
        self.non_memorised_cards = QtGui.QSpinBox(self.groupBox)
        self.non_memorised_cards.setMinimum(1)
        self.non_memorised_cards.setProperty("value", 10)
        self.non_memorised_cards.setObjectName(_fromUtf8("non_memorised_cards"))
        self.horizontalLayout.addWidget(self.non_memorised_cards)
        self.label_4 = QtGui.QLabel(self.groupBox)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.horizontalLayout.addWidget(self.label_4)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.label_5 = QtGui.QLabel(self.groupBox)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.horizontalLayout_4.addWidget(self.label_5)
        self.save_after_n_reps = QtGui.QSpinBox(self.groupBox)
        self.save_after_n_reps.setMinimum(1)
        self.save_after_n_reps.setMaximum(25)
        self.save_after_n_reps.setProperty("value", 10)
        self.save_after_n_reps.setObjectName(_fromUtf8("save_after_n_reps"))
        self.horizontalLayout_4.addWidget(self.save_after_n_reps)
        self.label_6 = QtGui.QLabel(self.groupBox)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.horizontalLayout_4.addWidget(self.label_6)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem3)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.verticalLayout_5.addWidget(self.groupBox)
        self.audio_box = QtGui.QGroupBox(ConfigurationWdgtMain)
        self.audio_box.setObjectName(_fromUtf8("audio_box"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.audio_box)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.media_autoplay = QtGui.QCheckBox(self.audio_box)
        self.media_autoplay.setChecked(True)
        self.media_autoplay.setObjectName(_fromUtf8("media_autoplay"))
        self.verticalLayout_2.addWidget(self.media_autoplay)
        self.media_controls = QtGui.QCheckBox(self.audio_box)
        self.media_controls.setChecked(False)
        self.media_controls.setObjectName(_fromUtf8("media_controls"))
        self.verticalLayout_2.addWidget(self.media_controls)
        self.verticalLayout_5.addWidget(self.audio_box)
        self.groupBox_3 = QtGui.QGroupBox(ConfigurationWdgtMain)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.groupBox_3)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.upload_science_logs = QtGui.QCheckBox(self.groupBox_3)
        self.upload_science_logs.setChecked(True)
        self.upload_science_logs.setObjectName(_fromUtf8("upload_science_logs"))
        self.verticalLayout_3.addWidget(self.upload_science_logs)
        self.verticalLayout_5.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(ConfigurationWdgtMain)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.groupBox_4)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.languages = QtGui.QComboBox(self.groupBox_4)
        self.languages.setObjectName(_fromUtf8("languages"))
        self.verticalLayout_4.addWidget(self.languages)
        self.verticalLayout_5.addWidget(self.groupBox_4)
        self.verticalLayout_6.addLayout(self.verticalLayout_5)

        self.retranslateUi(ConfigurationWdgtMain)
        QtCore.QMetaObject.connectSlotsByName(ConfigurationWdgtMain)

    def retranslateUi(self, ConfigurationWdgtMain):
        ConfigurationWdgtMain.setWindowTitle(_('Form'))
        self.groupBox.setTitle(_('Scheduler'))
        self.label_2.setText(_('Show new cards for the first time'))
        self.new_cards.setItemText(0, _('in the order they were added'))
        self.new_cards.setItemText(1, _('in random order'))
        self.label_3.setText(_('Review memorised cards'))
        self.scheduled_cards.setItemText(0, _('most urgent first'))
        self.scheduled_cards.setItemText(1, _('in random order'))
        self.label.setText(_('Hold'))
        self.label_4.setText(_('non-memorised cards in your hand'))
        self.label_5.setText(_('Autosave after'))
        self.label_6.setText(_('repetitions'))
        self.audio_box.setTitle(_('Audio/video'))
        self.media_autoplay.setText(_('Start automatically when displaying card'))
        self.media_controls.setText(_('Show controls (pause, ...)'))
        self.groupBox_3.setTitle(_('Science'))
        self.upload_science_logs.setText(_('Upload anonymous science logs'))
        self.groupBox_4.setTitle(_('Language'))

