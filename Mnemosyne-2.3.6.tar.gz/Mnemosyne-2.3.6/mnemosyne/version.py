version = "2.3.6"

if __name__ == "__main__":
    print version
